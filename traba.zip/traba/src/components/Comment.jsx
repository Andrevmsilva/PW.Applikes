import { Trash } from '@phosphor-icons/react/dist/ssr';
import styles from './Comment.module.css';
import { ThumbsUp } from '@phosphor-icons/react';

export function Comment() {
    return(
<div className={styles.comment}>
    <img src="https://cdn-icons-png.flaticon.com/512/4123/4123751.png"></img>
        <div className={styles.commentBox}>
             <div className={styles.commentContent}>
                <header>
                    <div className={styles.AuthorAndTime}>
                        <strong>Cara Estranho</strong>
                        <time title="10 de setembro às 09:44h" dateTime="2024/09/10 09:44:00">Há 1h atrás</time>
                    </div>
                    <button title='Excluir Comentário'>
                        <Trash size={24}/>
                    </button>
                </header>
                <p>Muito bem, Parabéns pelo siteee!!!</p>
            </div>
            <footer>
                <button>
                    <ThumbsUp size={20}/>
                    Curtir <span>20</span>
                </button>
            </footer>
        </div>
</div>

    );
}