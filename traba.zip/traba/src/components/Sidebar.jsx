import styles from './Sidebar.module.css'
import logog from '../assets/pointer.png'

export function Sidebar(){
    return(
       
        <img className={styles.posicao} src={logog} alt="" /> 
       
    );
}

