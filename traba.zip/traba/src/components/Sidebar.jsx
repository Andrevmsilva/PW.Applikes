import styles from './Sidebar.module.css'
import { PencilLine } from '@phosphor-icons/react';
import logog from '../assets/pointer.png'

export function Sidebar(){
    return(
     <aside className={styles.sidebar}>
     <div>
      <img src={logog} alt="" />
     </div>
      
     </aside>
    );
}

