import { Comment } from './Comment'
import styles from './Post.module.css'
import {format, formatDistanceToNow} from "date-fns";
import ptBR from 'date-fns/locale/pt-BR';


export function Post({author,dataPublicada,content}){

  const dataFormato= format(dataPublicada,"d 'de' LLLL 'às' HH:mm'h'", {locale: ptBR})
  const dataDoPost = formatDistanceToNow(dataPublicada,{locale: ptBR, addSuffix: true})
    return(
        <article className={styles.post}>
             <header>
                <div className={styles.author}>
                   <img className={styles.avatar} src={author.avatarUrl}/>
                
                <div className={styles.authorInfo}>
                  <strong>{author.nome}</strong>
                  <span>{author.cargo}</span>
                </div>
                </div>
                <time title={dataFormato} dateTime={dataPublicada.toISOString()}>{dataDoPost}</time>
             </header>
             <div className={styles.content}>
                 {
                  content.map(line =>{
                    if(line.type === 'paragraph'){
                      return <p>{line.content}</p>;
                    }
                    else if(line.type === 'link'){
                      return <p><a target='_blank' href={line.content}>{line.content}</a></p>
                    }
                  })
                 }
             </div>

             <form className={styles.commentForm} >

              <strong>Deixe seu feedback !</strong>

              <textarea placeholder='Deixe um comentário'></textarea>

              <footer >
              <button type='submit'>Publicar</button>
              </footer>


             </form>

              <div className={styles.commentList}>
                <Comment/>
                <Comment/>
              </div>
        </article>
    )
}