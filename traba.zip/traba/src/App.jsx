import { Header } from "./components/Header";
import styles from "./app.module.css";
import { Sidebar } from "./components/Sidebar";

import './global.css';
import { Post } from "./components/Post";

const posts = [
  {
    id:1,
    author:{
      avatarUrl: 'https://github.com/Andrevmsilva.png',
      nome:'André V.',
      cargo: 'Devenloper Web'

    },
    content: [
      {type: 'paragraph', content: 'Fala Galera !!!' },
      {type: 'paragraph', content: 'Pointer é um site inovador dedicado a recomendar jogos de forma interativa e divertida. A plataforma permite que os usuários explorem uma ampla variedade de jogos, facilitando a descoberta  de novos títulos que podem se alinhar aos seus interesses.' },
      {type: 'link', content: 'https://pleaselike.com' }
    ],
    dataPublicada: new Date('2024/09/10 09:44:00')
  },
  {
    id: 2,
    author:{
      avatarUrl: 'https://cdn-icons-png.flaticon.com/512/4123/4123751.png',
      nome: 'Cara Estranho',
      cargo: 'Desempregado'
    },
    content: [
      {type: 'paragraph', content: 'QUE MARAVILHOSO, FAZ TEMPO QUE EU ESTAVA ESPERANDO !!!' },
      {type: 'paragraph', content: 'Quero elogiar vc pelo seu esforço e agradecer por ser um dos primeiros a conseguir acessar o site !' },
      {type: 'link', content: 'https://github.com' }
    ],
    dataPublicada: new Date('2024/09/10 09:45:00')
  },

]

export function App() {
  return (
  <div>

    <Header/>

     <div className={styles.corpo}>
       
       <Sidebar/>

       <main> 
        {posts.map(post => {
          return (
          <Post
          author={post.author}
          content={post.content}
          dataPublicada={post.dataPublicada}
          />
        
        
          )
        })}
       </main>


     </div>

  </div>

  )
}

