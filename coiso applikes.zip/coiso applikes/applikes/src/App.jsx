import { Header } from "./components/Header";
import styles from "./app.module.css";
import { Sidebar } from "./components/Sidebar";

import './global.css';
import { Post } from "./components/Post";

//vai mudar: 
//author: {avatarUrl: "", nome "",cargo: ""}
//dataPublicacao: Date
//content: string

const posts = [
  {
    id: 1,
    author:{
      avatarUrl: 'https://github.com/Andrevmsilva.png',
      nome: 'André V.',
      cargo: 'Devenloper Web'
    },
    content: [
      {type: 'paragraph', content: 'Fala Galera !!!' },
      {type: 'paragraph', content: 'Amanhã teremos viagem a Bienal !!!' },
      {type: 'link', content: 'oul.com.br' },
    ],
    dataPublicacao: new Date('2024/09/10 09:44:00')
  },
  {
    id: 2,
    author:{
      avatarUrl: 'https://github.com/furlanrogerio.png',
      nome: 'Rogério Furlan.',
      cargo: 'Professor Etec'
    },
    content: [
      {type: 'paragraph', content: 'Fala Galera !!!' },
      {type: 'paragraph', content: 'Amanhã Bienal !!!' },
      {type: 'link', content: 'g1.com.br' },
    ],
    dataPublicacao: new Date('2024/11/05 09:44:00')
  },
]

export function App() {
  return (
  <div>

    <Header/>

     <div className={styles.wrapper}>
       
       <Sidebar/>

       <main> 
           
       {posts.map(post => {
        return (
        <Post
          author={post.author}
          content={post.content}
          dataPublicacao = {post.dataPublicacao}
        />
        )
        })}
       </main>


     </div>

  </div>

  )
}

