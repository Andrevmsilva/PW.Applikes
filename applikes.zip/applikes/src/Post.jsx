export function Post(Props){
    return(
        <div>

         <strong>{Props.author}</strong>
         <p>{Props.coment}</p>
         
         </div>
    )
}

