import { Post } from "./Post";
import { Header } from "./components/Header";
import styles from "./App.module.css"
import './global.css';
import { Sidebar } from "./components/Sidebar";

export function App() {
  return (
  <div>

    <Header/>
    <div className={styles.wrapper}>
      <Sidebar/>
      <main>
       <Post
        author="Machado de assis"
        coment="Lorem ipsum dolor sit amet consectetur adipisicing elit."/>
  
       <Post
        author="Castro Alves"
        coment="Lorem ipsum dolor sit amet consectetur adipisicing elit."/>
  
       <Post
        author="Padre Antonio Vieira"
        coment="Lorem ipsum dolor sit amet consectetur adipisicing elit."/>
      </main>
    </div>
  </div>

  )
}

